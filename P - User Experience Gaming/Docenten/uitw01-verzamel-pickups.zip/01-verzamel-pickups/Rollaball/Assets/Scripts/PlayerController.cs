using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    public float speed = 0;
    private Rigidbody rb;
    private float movementX;
    private float movementY;

    private int resterendePickUps;
    void Start()
    {
        rb = GetComponent<Rigidbody>();

        //Zorg hier dat resterendePickUps de juiste start-waarde krijgt
        resterendePickUps = 
            GameObject.FindGameObjectsWithTag("PickUp").Length;
    }

    void OnMove(InputValue movementValue)
    {
        Vector2 movementVector = movementValue.Get<Vector2>();

        movementX = movementVector.x;
        movementY = movementVector.y;
    }

    void FixedUpdate()
    {
        Vector3 movement = new Vector3(movementX, 0.0f, movementY);

        rb.AddForce(movement * speed);
    }

    void OnTriggerEnter(Collider other) 
    {
        if (other.gameObject.CompareTag("PickUp"))
        {
            other.gameObject.SetActive(false);

            //Plaats hier de code om resterendePickups met 1 te verlagen
            resterendePickUps--;

            Debug.Log(resterendePickUps);

            //Plaats hier de code waarmee 
            //  - je controleert dat alle pickups zijn verzameld
            //  - de tekst naar de console schrijft 
            if (resterendePickUps <= 0)
            {
                Debug.Log("Het doel is behaald");
            }
        }
    }
}

