using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HealthController : MonoBehaviour
{
    private Rigidbody rb;

    //De waarde van levens kan bepaald worden in de editor
    public int levens;

    void Start() 
    {
        rb = GetComponent<Rigidbody>();
    }

    public void Geraakt(Vector3 wegschietRichting) 
    {
        rb.AddForce(wegschietRichting * 5, ForceMode.Impulse);
        
        levens--;

        if (levens < 0)
        {
            SceneManager.LoadScene("MiniGame");
        }
    }

    // Testfunctie om de speler op een willekeurig moment te kunnen raken
    // void OnTest()
    // {
    //     Geraakt(Vector3.left);
    // }
}