using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BalRaker : MonoBehaviour
{
        void OnCollisionEnter(Collision other) 
        {
            string naamSlachtoffer = other.gameObject.name;
            Debug.Log("We prikken: ");
            Debug.Log(naamSlachtoffer);

            HealthController healthController = 
                other.gameObject.GetComponent<HealthController>();
            
            healthController.Geraakt(Vector3.up);
        }
}
