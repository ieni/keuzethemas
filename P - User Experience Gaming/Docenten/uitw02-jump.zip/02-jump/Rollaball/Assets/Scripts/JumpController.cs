using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpController: MonoBehaviour
{    
    private Rigidbody rb;

    void Start() 
    {
        rb = GetComponent<Rigidbody>();
    }

    void OnJump() 
    {     
        if (isOpDeGrond())
        {
            Debug.Log("Nu moet ik springen");
            Vector3 jumpForce = Vector3.up * 5; /* Vul hier de vector in */
            rb.AddForce(jumpForce, ForceMode.Impulse);
        }
    }

    private bool isOpDeGrond()
    {
        //Retourneert true als de bal zich op de grond bevindt
        Vector3 startpunt = transform.position;// Vul hier het startpunt van de lijn in
        Vector3 richting = Vector3.down;// Vul hier de richting van de lijn in
        float lengte = 0.55f; 
        return Physics.Raycast(startpunt, richting, lengte);
    }
}